<?php 

include("imap-attachment.php");

$savedir = __DIR__ . '/imap-dump/';


$hostname = 'box263.bluehost.com';
$username = 'ikr@iipcc.org';
$password = 'bk4rypyl2pyg';
$encryption = 'ssl';


$inbox = new IMAPMailbox($hostname, $username, $password);

$emails = $inbox->search('ALL');
if ($emails) {
    rsort($emails);
    foreach ($emails as $email) {
        foreach ($email->getAttachments() as $attachment) {
            $savepath = $savedir . $attachment->getFilename();
            file_put_contents($savepath, $attachment);
        }
    }
}


?>
