<?PHP


ini_set('display_errors',1);
ini_set('log_errors',1);

require_once "Imap_class.php";

$mailbox = 'box263.bluehost.com';
$username = 'ikr@iipcc.org';
$password = 'bk4rypyl2pyg';
$encryption = 'ssl';
$save_attc_location = '/';
 // or ssl or ''

// open connection
$imap = new Imap($mailbox,$username,$password);

echo '<pre>';

// stop on error
if($imap->isConnected()===false)
    die($imap->getError());

// get all folders as array of strings
$folders = $imap->getFolders();
foreach($folders as $folder)
    echo $folder;

// select folder Inbox
$imap->selectFolder('INBOX');

// count messages in current folder
$overallMessages = $imap->countMessages();
$unreadMessages = $imap->countUnreadMessages();

// fetch all messages in the current folder
$emails = $imap->getMessages($save_attc_location);
var_dump($emails);

// add new folder for archive
$imap->addFolder('archive');

// move the first email to archive
$imap->moveMessage($emails[0]['uid'], 'archive');

// delete second message
$imap->deleteMessage($emails[1]['uid']);
