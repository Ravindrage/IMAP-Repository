<?php //$con = mysql_connect("localhost","root","");

//if (!$con)
//{ die('Could not connect: ' . mysql_error()); }

//mysql_select_db("vertrigo", $con);



//$servername = "localhost";
//$username = "root";
//$password = "";
//$dbname = "vertrigo";


$servername = "localhost";
$username   = "jsramco_ocar530";
$password   = "59@P20V(SI";
$dbname     = "jsramco_phpimap";

// Create connection
global $conn;
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 







?>
